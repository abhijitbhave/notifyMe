# notifyMe

Download the code and you can run the code leveraging the main method in notifyMe.java
